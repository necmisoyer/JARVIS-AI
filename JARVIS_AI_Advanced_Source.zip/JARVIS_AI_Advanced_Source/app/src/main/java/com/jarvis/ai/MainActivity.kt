package com.jarvis.ai

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var response: TextView
    private lateinit var history: TextView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var listening = false
    private val handler = Handler(Looper.getMainLooper())
    private val cyan = Color.rgb(84, 217, 255)
    private val dark = Color.rgb(3, 9, 20)
    private val panel = Color.rgb(8, 25, 43)
    private val white = Color.rgb(230, 245, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = dark
        window.navigationBarColor = dark
        tts = TextToSpeech(this, this)
        buildScreen()
    }

    override fun onInit(statusCode: Int) {
        ttsReady = statusCode == TextToSpeech.SUCCESS
        if (ttsReady) {
            val result = tts?.setLanguage(Locale("tr", "TR"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                updateStatus("Türkçe ses cihazda bulunamayabilir")
            }
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(18), dp(18), dp(14))
            setBackgroundColor(dark)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 30f
            letterSpacing = .20f
            setTextColor(cyan)
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        content.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "KİŞİSEL YAPAY ZEKÂ • ALFA 1.0"
            textSize = 11f
            letterSpacing = .13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(18))
        }
        content.addView(subtitle, matchWrap())

        val orb = TextView(this).apply {
            text = "◉  ◉
━━━━━━"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(cyan)
            typeface = Typeface.MONOSPACE
            background = rounded(Color.rgb(5, 29, 51), cyan, 2)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        content.addView(orb, LinearLayout.LayoutParams(-1, dp(100)).apply { bottomMargin = dp(12) })
        status = TextView(this).apply {
            text = "SİSTEM HAZIR • ÇEVRİMDIŞI KOMUTLAR"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(100, 255, 170))
            setPadding(0, 0, 0, dp(12))
        }
        content.addView(status, matchWrap())
        response = TextView(this).apply {
            text = "Merhaba. Ben JARVIS. Komutunu bekliyorum.

Örnek: ‘YouTube'da Minecraft ara’, ‘Ayarları aç’, ‘Saat kaç?’"
            textSize = 15f
            setTextColor(white)
            gravity = Gravity.CENTER
            background = rounded(panel, Color.rgb(28, 111, 145), 1)
            setPadding(dp(16), dp(18), dp(16), dp(18))
        }
        content.addView(response, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        content.addView(button("🎙  KONUŞ VE KOMUT VER") { startListening() }, buttonParams())
        content.addView(button("⌕  WEB'DE ARA") { askText("Ne aramamı istiyorsun?") { q -> openUrl("https://www.google.com/search?q=" + android.net.Uri.encode(q)) } }, buttonParams())
        content.addView(button("◷  SAAT VE TARİH") { tellTime() }, buttonParams())
        content.addView(button("▶  YOUTUBE AÇ / ARA") { askText("YouTube'da ne arayayım?") { q -> openUrl("https://www.youtube.com/results?search_query=" + android.net.Uri.encode(q)) } }, buttonParams())
        content.addView(button("⚙  ANDROID AYARLARI") { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)); say("Android ayarlarını açıyorum.") }, buttonParams())
        content.addView(button("📝  HIZLI NOT AL") { askText("Notunu yaz") { note ->
            val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
            val old = prefs.getString("notes", "") ?: ""
            val stamp = SimpleDateFormat("dd.MM HH:mm", Locale("tr", "TR")).format(Date())
            prefs.edit().putString("notes", (old + "
[$stamp] $note").trim()).apply()
            reply("Notunu kaydettim: $note")
        } }, buttonParams())
        content.addView(button("📚  KAYITLI NOTLARI GÖSTER") { showNotes() }, buttonParams())
        content.addView(button("♿  EKRAN KONTROLÜ AYARLARI") {
            startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
            reply("Erişilebilirlik ayarlarını açtım. JARVIS servisini yalnızca güveniyorsan kendin etkinleştir.")
        }, buttonParams())

        history = TextView(this).apply {
            text = "GÖREV GÜNLÜĞÜ
Henüz görev yok."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            background = rounded(Color.rgb(5, 15, 28), Color.rgb(23, 62, 83), 1)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        content.addView(history, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(10) })
        val footer = TextView(this).apply {
            text = "ALFA SÜRÜMÜ • Genel yapay zekâ ve otomatik ekran görevleri henüz bağlı değil."
            textSize = 11f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(8), dp(4), dp(12))
        }
        content.addView(footer, matchWrap())
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            reply("Bu cihazda konuşma tanıma hizmeti bulunamadı."); return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 42); return
        }
        listening = true
        updateStatus("DİNLİYOR…")
        val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { updateStatus("KOMUT İŞLENİYOR…") }
            override fun onError(error: Int) {
                listening = false; updateStatus("SİSTEM HAZIR")
                reply("Seni anlayamadım. Biraz daha net söyleyebilir misin?")
                recognizer.destroy()
            }
            override fun onResults(results: Bundle?) {
                listening = false
                val command = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                updateStatus("SİSTEM HAZIR")
                recognizer.destroy()
                if (command.isNullOrBlank()) reply("Komut anlaşılmadı.") else handleCommand(command)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS komutunu dinliyor")
        }
        recognizer.startListening(intent)
    }

    private fun handleCommand(raw: String) {
        val c = raw.lowercase(Locale("tr", "TR"))
        addHistory("Komut: $raw")
        when {
            "saat" in c || "tarih" in c || "kaç" in c && "saat" in c -> tellTime()
            "youtube" in c && ("ara" in c || "bul" in c || "video" in c) -> {
                val q = raw.replace(Regex("(?i)youtube'da|youtube da|youtube|ara|bul|video|aç"), "").trim()
                if (q.isBlank()) askText("YouTube'da ne arayayım?") { openUrl("https://www.youtube.com/results?search_query=" + android.net.Uri.encode(it)) }
                else openUrl("https://www.youtube.com/results?search_query=" + android.net.Uri.encode(q))
                reply("YouTube aramasını açıyorum: ${q.ifBlank { "arama" }}")
            }
            "youtube" in c -> { openUrl("https://www.youtube.com"); reply("YouTube'u açıyorum.") }
            "google" in c || "internette ara" in c || "web'de ara" in c -> {
                val q = raw.replace(Regex("(?i)google'da|google da|google|internette ara|web'de ara|ara"), "").trim()
                if (q.isBlank()) askText("İnternette ne arayayım?") { openUrl("https://www.google.com/search?q=" + android.net.Uri.encode(it)) }
                else openUrl("https://www.google.com/search?q=" + android.net.Uri.encode(q))
                reply("İnternet aramasını açıyorum.")
            }
            "ayar" in c -> { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)); reply("Android ayarlarını açıyorum.") }
            "not al" in c || "not yaz" in c -> askText("Notunu yaz") { note ->
                val p = getSharedPreferences("jarvis", MODE_PRIVATE)
                val old = p.getString("notes", "") ?: ""
                val stamp = SimpleDateFormat("dd.MM HH:mm", Locale("tr", "TR")).format(Date())
                p.edit().putString("notes", (old + "
[$stamp] $note").trim()).apply()
                reply("Notunu kaydettim.")
            }
            "notlar" in c || "notlarımı göster" in c -> showNotes()
            else -> reply("Komutunu duydum: $raw. Bu alfa sürümünde genel yapay zekâ bağlantısı henüz kurulmadı.")
        }
    }

    private fun tellTime() {
        val now = Date()
        reply("Saat ${SimpleDateFormat("HH:mm", Locale("tr", "TR")).format(now)}. Tarih ${SimpleDateFormat("d MMMM yyyy", Locale("tr", "TR")).format(now)}.")
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))) }
        catch (_: Exception) { Toast.makeText(this, "Bağlantı açılamadı.", Toast.LENGTH_SHORT).show() }
    }

    private fun askText(title: String, onText: (String) -> Unit) {
        val input = EditText(this).apply { hint = "Buraya yaz…"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        val box = LinearLayout(this).apply { setPadding(dp(20), dp(4), dp(20), 0); addView(input, LinearLayout.LayoutParams(-1, -2)) }
        AlertDialog.Builder(this).setTitle(title).setView(box)
            .setNegativeButton("İptal", null)
            .setPositiveButton("Devam") { _, _ -> val value = input.text.toString().trim(); if (value.isNotEmpty()) onText(value) }
            .show()
    }

    private fun showNotes() {
        val notes = getSharedPreferences("jarvis", MODE_PRIVATE).getString("notes", "")?.ifBlank { "Henüz kayıtlı not yok." } ?: "Henüz kayıtlı not yok."
        AlertDialog.Builder(this).setTitle("JARVIS • Notlar").setMessage(notes).setPositiveButton("Kapat", null).show()
    }

    private fun reply(text: String) {
        response.text = text
        updateStatus("YANIT HAZIR")
        addHistory(text)
        say(text)
    }

    private fun say(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-${System.currentTimeMillis()}")
    }

    private fun addHistory(line: String) {
        if (!::history.isInitialized) return
        val old = history.text.toString().removePrefix("GÖREV GÜNLÜĞÜ
Henüz görev yok.")
        val lines = (old.lines().filter { it.isNotBlank() } + line).takeLast(6)
        history.text = "GÖREV GÜNLÜĞÜ
" + lines.joinToString("
")
    }

    private fun updateStatus(text: String) { if (::status.isInitialized) status.text = text }
    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 13f; setTextColor(white)
        background = rounded(Color.rgb(7, 37, 60), cyan, 1)
        setOnClickListener { action() }
    }
    private fun buttonParams() = LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun rounded(fill: Int, stroke: Int, width: Int): GradientDrawable = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(16).toFloat(); setStroke(dp(width), stroke)
    }
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        tts?.stop(); tts?.shutdown(); super.onDestroy()
    }
}

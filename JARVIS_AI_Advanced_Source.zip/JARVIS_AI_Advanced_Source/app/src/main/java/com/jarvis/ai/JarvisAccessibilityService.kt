package com.jarvis.ai

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/** Opt-in foundation for future user-authorized screen automation. */
class JarvisAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // This alpha does not click or type autonomously yet.
    }
    override fun onInterrupt() {}
}

# JARVIS AI — gelişmiş başlangıç kaynak projesi

Bu proje, kullanıcının önceki `ULTRON_AI_Alpha_Source.zip` projesinin aynı basit Android/Kotlin ve Gradle yapısından yararlanılarak JARVIS adıyla geliştirilmiş bir başlangıç sürümüdür. **ZIP bir APK değildir; henüz derlenmiş/test edilmiş APK içermez.**

## Bu sürümde
- Koyu mavi, bilim kurgu tarzı JARVIS arayüzü
- Android konuşma tanıma servisiyle Türkçe sesli komut alma
- Cihazın Türkçe TTS sesi varsa sesli yanıt
- Saat/tarih söyleme
- YouTube'u açma ve YouTube'da arama
- Google/web araması
- Android Ayarları'nı açma
- Not kaydetme ve kayıtlı notları gösterme
- Son komut/yanıt günlüğü
- İsteğe bağlı Android AccessibilityService temeli (kendi kendine tıklama veya yazma bu sürümde etkin değil)
- GitHub Actions iş akışıyla kendi deposunda APK derleme taslağı

## Henüz yok
- Genel amaçlı sohbet için bağlı bir yapay zekâ modeli
- Kendi kendine plan yapan, uygulamalar arasında tüm görevleri tamamlayan ve sonucu doğrulayan tam otomasyon
- Arka planda sürekli dinleme / uyandırma kelimesi
- Derlenmiş APK

Bu özellikler için güvenli bir yapay zekâ servisi bağlantısı, uygulama içinde açık izinler ve gerçek cihaz testleri gerekir. API anahtarını APK içine koymayın.

## GitHub Actions ile derleme
1. ZIP'i açın; içindeki `JARVIS_AI_Advanced_Source` klasörünün **içeriğini** kendi GitHub deposuna yükleyin (üst klasörün kendisini değil).
2. `.github/workflows/build-apk.yml` dosyasının da yüklendiğinden emin olun.
3. Depoda **Actions** sekmesini açıp `Build JARVIS APK` iş akışını çalıştırın.
4. Başarılı çalışırsa iş akışının altındaki **Artifacts** bölümünden `JARVIS-debug-APK` dosyasını indirin.

Derleme GitHub'ın kendi Actions altyapısında çalışır. AndroidForge gibi üçüncü taraf sayfalara kişisel erişim belirteci (PAT) vermeniz gerekmez. GitHub hesabında Actions kapalıysa depo ayarlarından etkinleştirmek gerekir.

## Yerel derleme
Android Studio, JDK 17 ve Android SDK 35 gerekir. Projede Gradle wrapper dahil değildir; uyumlu derleme ortamı kurulu Gradle kullanmalıdır.

## Güvenlik
Mikrofon izni Android tarafından istenir. Erişilebilirlik servisi otomatik açılmaz; kullanıcı Ayarlar'dan açıkça etkinleştirmelidir. Bu alfa sürümünü hassas hesaplarda denemeyin; erişilebilirlik servisi henüz görev yürütmüyor.
